---
_type: task
_title: Task 2.2
effort: 0.5
stage: todo
belongsTo: "[[projects/release-plan/task-2.md]]"
---
