---
_type: task
_title: Task 3
effort: 4
blocked: true
belongsTo: "[[projects/release-plan/task-2.md]]"
---
