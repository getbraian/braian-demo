---
_type: task
_title: Task 2.1
effort: 0.5
stage: done
belongsTo: "[[projects/release-plan/task-2.md]]"
---
