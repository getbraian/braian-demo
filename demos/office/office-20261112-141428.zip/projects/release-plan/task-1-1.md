---
_type: task
_title: Task 1.1
effort: 3
stage: wip
responsible: "[[people/mike.md]]"
belongsTo: "[[projects/release-plan/task-1.md]]"
---
