---
_type: task
_title: Task 1.2
effort: 1.5
belongsTo: "[[projects/release-plan/task-1.md]]"
---
