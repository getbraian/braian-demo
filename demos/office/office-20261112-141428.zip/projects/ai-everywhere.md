---
_type: project
_title: AI Everywhere
Team:
  - "[[teams/product.md]]"
Leader: "[[people/george.md]]"
---

AI is coming, we need to sell it!

![[sell-me-this-pen.jpeg|327x337]]
