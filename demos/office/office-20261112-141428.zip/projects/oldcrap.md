---
_type: project
_title: OldCrap
Team:
  - "[[teams/platform.md]]"
---

The OldCrap is a tech-debpt payback project for the [[platform|Platform]] team.
The goal is to streamline how we build new software.
