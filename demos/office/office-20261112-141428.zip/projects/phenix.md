---
_type: project
_title: Phenix
Team:
  - "[[teams/product.md]]"
Leader: "[[people/george.md]]"
---

The Phenix project aims to make our company super profitable!
