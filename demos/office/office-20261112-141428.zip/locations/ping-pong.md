---
_type: location
_title: Ping Pong
type: meeting room
---


