---
_type: location
_title: Very Big Room
type: meeting room
---


