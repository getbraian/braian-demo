---
_type: location
_title: Dock Side
type: restaurant
---


