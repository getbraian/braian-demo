---
_type: meeting
_title: AI Bot Kickoff
Date: 2026-10-07T14:00
Participants:
  - "[[teams/product.md]]"
Topic:
  - "[[projects/ai-everywhere.md]]"
Location: "[[locations/online-meeting.md]]"
---

A lot of talks how to do it.
