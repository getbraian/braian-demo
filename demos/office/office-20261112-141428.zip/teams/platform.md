---
_type: team
_title: Platform
---

Team in charge of system improvement so that [[product|Product]] works faster.
