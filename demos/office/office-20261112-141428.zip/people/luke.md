---
_type: person
_title: Luke
Role: QA
Team:
  - "[[teams/platform.md]]"
  - "[[teams/product.md]]"
---

- Test automation guru
