---
_type: person
_title: Sarah
Team:
  - "[[teams/product.md]]"
Role: Engineer:Frontend
---

- Frontend dev, heavily involved in AI
