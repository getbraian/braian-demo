---
_type: person
_title: Mike
Team:
  - "[[teams/product.md]]"
Role: Engineer:Backend
---

- Backend guy
- Likes trekking
