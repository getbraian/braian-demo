---
_type: person
_title: John
Team:
  - "[[teams/platform.md]]"
Role: Engineer:Backend
---

- Java developer converting to Rust
