---
_type: task
_title: Remove Java backend
Project: "[[projects/oldcrap.md]]"
Members:
  - "[[teams/platform.md]]"
Assignee: "[[people/mike.md]]"
---

# Elevator's Pitch:

These days, either you do things in Rust, or you are nobody.

# Business Value:

We don't want to be nobody.

# Current State:

We use Java.

# Desired State:

We use Rust.

# How To Test It

- [ ] `grep -R . --detect-enterprise-patterns --min-abstract-factories=3 --sniff-beans`
