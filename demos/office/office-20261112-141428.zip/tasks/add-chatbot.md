---
_type: task
_title: Add Chatbot
Project: "[[projects/ai-everywhere.md]]"
Assignee: "[[people/john.md]]"
---

# Elevator's Pitch:

Who doesn't love a chatbot?

# Business Value:

Chatbots make life worth living!

# Current State:

We don't have one.

# Desired State:

We have one.

# How To Test It

- [ ] Do we have one?

# DoD

- [ ] We are done when we have a chatbot
